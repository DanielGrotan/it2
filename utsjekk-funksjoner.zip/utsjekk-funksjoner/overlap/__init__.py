from .overlap import boxes_overlap, intervals_overlap
